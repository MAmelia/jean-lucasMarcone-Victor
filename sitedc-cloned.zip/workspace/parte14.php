	<!Doctype HTML>
		<html>
		<head>
			<title> DC COMICS </title>
				<meta charset="UTF-8">
				
				<link rel = "stylesheet" type = "text/css" href="csmarvel.css">
	   </head>
		<body id="corpo1">
        <section id="layout">
				<header>
					<img class="img1" src="dc_comics_logo_2.png" alt="Imagem">					
                    <h1 class="titulo"> DC COMICS <a href="login.php"> <img src="seu-cadastro.png" id="imgcadastro" alt="Ver seu cadastro"></a> </h1>
					
				</header>
	  <!--Menu-->
		
				<?php include"menu.php"?>
			
		
		     <a href="index.php"><img class="next" src="next.png" alt="Botão-próxima-página" ></a>  
                   <a href="parte13.php"> <img class="previous" src="previous.png" alt="Botão-anterior-página" ></a>
             <article id="texto"></br>
            </br>
            
            <a id="Introducao">
                </br></br><p><center>
            <img class="img2" src="seriesdc.jpg" alt="SÉRIES DC" >
            <h3> <center>Filmes DC</center></h3> </a>
               
            <div style="text-align:justify">
<p> Em comunicado oficial, o estúdio diz ainda que lançará filmes solos de Batman e Superman nesse período até 2020.</p>
<ul>
    2016

<li>Batman V Superman</li>
<li>Esquadrão Suicida</li>
</ul>
<ul>
2017

<li>Mulher-Maravilha, com Gal Gadot.</li>
<li>Liga da Justiça</li>
</ul>

2018
<ul>
<li>The Flash, com Ezra Miller.</li>
<li>Aquaman, com Jason Momoa.</li>
</ul>
2019 e 2020
<ul>
<li>2019 - Shazam, com Dwayne Johnson como Adão Negro e Liga da Justiça 2</li>
<li>2020 - Ciborgue, com Ray Fisher e Lanterna Verde</li>  
            </br></br></br>

</div>
			
		</article>
            <footer><center> Site academico.</br>
               </center>
                    </footer>
            </section>
	   </body>
	


	</html>