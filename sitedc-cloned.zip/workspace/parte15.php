	<!Doctype HTML>
		<html>
		<head>
			<title> DC COMICS </title>
				<meta charset="UTF-8">
				
				<link rel = "stylesheet" type = "text/css" href="csmarvel.css">
				
	   </head>
		<body id="corpo1">
        <section id="layout">
				<header>
					<img class="img1" src="dc_comics_logo_2.png" alt="Imagem">					
                    <h1 class="titulo"> DC COMICS <a href="login.php"> <img src="seu-cadastro.png" id="imgcadastro" alt="Ver seu cadastro"></a> </h1>
					
				</header>
	  <!--Menu-->
		
				<?php include"menu.php"?>

			
		
		     <a href="index.php"><img class="next" src="next.png" alt="Botão-próxima-página" ></a>  
                   <a href="parte14.php"> <img class="previous" src="previous.png" alt="Botão-anterior-página" ></a>
             <article id="texto"></br>
            </br>
            
            <a id="Introducao">
                </br></br><p><center>
            <img src="alerta.jpg" alt="Alerta"   > 
            <h2>Desculpe, Pagina em criação</h2>
            </center>
</p>
</div>
			
		</article>
            <footer><center>Site academico.</br>
                </center>
                    </footer>
            </section>
	   </body>
	


	</html>