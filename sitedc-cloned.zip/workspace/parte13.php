	<!Doctype HTML>
		<html>
		<head>
			<title> DC COMICS </title>
				<meta charset="UTF-8">
				
				<link rel = "stylesheet" type = "text/css" href="csmarvel.css">
				
	   </head>
		<body id="corpo1">
        <section id="layout">
				<header>
					<img class="img1" src="dc_comics_logo_2.png" alt="Imagem">					
                    <h1 class="titulo"> DC COMICS <a href="login.php"> <img src="seu-cadastro.png" id="imgcadastro" alt="Ver seu cadastro"></a> </h1>
					
				</header>
	  <!--Menu-->
		
				<?php include"menu.php"?>

			
		
		     <a href="parte14.php"><img class="next" src="next.png" alt="Botão-próxima-página" ></a>  
                   <a href="parte12.php"> <img class="previous" src="previous.png" alt="Botão-anterior-página" ></a>
             <article id="texto"></br>
            </br>
            
            <a id="Introducao">
                </br></br><p><center>
           <img class="img2" src="seriesdc.jpg" alt="SÉRIES DC" >
            <h3> <center>Séries DC</center></h3> </a>
               
        
            <div style="text-align:justify">
<p> A DC Comics, conhecida por famosos títulos de super-heróis como Batman, Super-Homem, The Flash, Mulher Maravilha, está expandindo o seu universo para além do cinema.

Com produções cinematográficas como a trilogia de Batman de Christopher Nolan (2005-2012) e Homem de Aço (2013), que ganhará continuação em Batman v Superman: Dawn Of Justice ( 28 de abril de 2016), um prelúdio para o filme da Liga da Justiça; o universo cinematográfico da DC ainda caminha lentamente, quanto sua concorrente, a Marvel Entertainment, já apresentou diversos filmes solo de seus super-heróis e caminha para sua segunda reunião de heróis, Os Vingadores: A Era de Ultron.

Enquanto a DC constrói as histórias-base dos seus maiores super-heróis no cinema, o universo das série de TV fervilham com vigilantes mascarados e heróis fazendo de tudo para salvar suas cidades e as pessoas que mais estimam.

Atualmente, a DC possui em exibição e produção quatro seriados semanais: Arrow, The Flash, Gotham e Constantine. Mas seus planos não param por aí, em planejamento e pré-produção estão Supergirl, Kripton, Os Jovens Titãs e Super Choque..</p>
              
            </br></br></br>
</div>
			
		</article>
            <footer><center> Site academico.</br>
                </center>
                    </footer>
            </section>
	   </body>
	


	</html>