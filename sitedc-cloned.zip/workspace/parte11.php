	<!Doctype HTML>
		<html>
		<head>
			<title> DC COMICS </title>
				<meta charset="UTF-8">
				
				<link rel = "stylesheet" type = "text/css" href="csmarvel.css">
	   </head>
		<body id="corpo1">
        <section id="layout">
				<header>
					<img class="img1" src="dc_comics_logo_2.png" alt="Imagem">					
                    <h1 class="titulo"> DC COMICS <a href="login.php"> <img src="seu-cadastro.png" id="imgcadastro" alt="Ver seu cadastro"></a> </h1>
					
				</header>
	  <!--Menu-->
		
				<?php include"menu.php"?>
			
		
		     <a href="parte12.php"><img class="next" src="next.png" alt="Botão-próxima-página" ></a> 
                   <a href="parte10.php"> <img class="previous" src="previous.png" alt="Botão-anterior-página" ></a>
             <article id="texto"></br>
            </br>
            
            <a id="Introducao">
                </br></br>
            <p><img class="img2" src="rebirth1.jpg" alt="renascimento" >
            <h3> <center>Rebirth</center></h3> </a>
               
        
            <div style="text-align:justify">
<p>  A história terá mistérios e surpresas, com reflexos em todas as revistas mensais da editora, que contarão com novos autores e serão relançadas a partir do primeiro número.
Não se trata de um novo reboot na cronologia, como ocorrido em 2011. Os planos foram revelados em detalhes durante a WonderCon de Los Angeles (veja todos os detalhes aqui), incluindo transmissão ao vivo pela internet, a presença da equipe editorial e diversos escritores e desenhistas.
“Tenho muito orgulho de todo este tempo que estou na DC e temos o compromisso de lançar revistas que sejam tão empolgantes para os leitores quanto são para nós. Crise Infinita continua sendo um dos meus momentos favoritos. Lançamos os Novos 52 e foi uma das épocas mais empolgantes da editora”, relembrou o editor Dan DiDio. “Mas, às vezes, nós nos desviamos do caminho e perdemos a conexão com os fãs. Todo o propósito de Rebirth é mostrar o nosso comprometimento com os leitores e a nossa dedicação com esses personagens. Algo estava faltando e percebemos isso.”.</p>
                 </br></br></br>
			
         
                
</div>
			
		</article>
            <footer><center> Site academico.</br>
                </center>
                    </footer>
            </section>
	   </body>
	


	</html>