	<!Doctype HTML>
		<html>
		<head>
			<title> DC COMICS </title>
				<meta charset="UTF-8">
				
				<link rel = "stylesheet" type = "text/css" href="csmarvel.css">
				
	   </head>
		<body id="corpo1">
        <section id="layout">
				<header>
					<img class="img1" src="dc_comics_logo_2.png" alt="Imagem">					
                    <h1 class="titulo"> DC COMICS <a href="login.php"> <img src="seu-cadastro.png" id="imgcadastro" alt="Ver seu cadastro"></a> </h1>
					
				</header>
	  <!--Menu-->
		
				<?php include"menu.php"?>

			
		
		     <a href="parte7.php"><img class="next" src="next.png" alt="Botão-próxima-página" ></a>  
                   <a href="parte5.php"> <img class="previous" src="previous.png" alt="Botão-anterior-página" ></a>
             <article id="texto"></br>
            </br>
            
            <a id="Introducao">
                </br></br>
            <p><img class="img2" src="aquaman1.jpeg" alt="Aquaman" >
            <h3> <center>Aquaman</center></h3> </a>
               
        
            <div style="text-align:justify">
	<p> Aquaman é um super-herói dos quadrinhos que aparece na DC Comics. Criado por Paul Norris e Mort Weisinger, o personagem estreou na More Fun Comics #73 (novembro de 1941). Inicialmente um herói secundário em títulos da antologia da DC, Aquaman depois estrelou em vários volumes como herói principal. Durante o final dos anos 1950 e 1960, período do renascimento dos super-heróis, conhecido como Era de Prata dos Quadrinhos, ele era um membro fundador da Liga da Justiça da América. Na década de 1990, a Era Moderna dos Quadrinhos, o personagem Aquaman tornou-se mais sério do que na maioria das interpretações anteriores, com enredos que descreve o peso de seu papel como o rei da Atlântida. Em 2011, durante a realidade alternativa da saga Flashpoint, um novo perfil foi dado ao personagem pela DC.

    <ul><li>Nessa nova realidade Aquaman é um déspota tirano que está em guerra com a Mulher Maravilha e suas Amazonas.</li>
    <li>Ele, junto com seu exército, inundou metade da Europa.</li>
                </ul>

</p>
                 </br></br></br>
			
         
               
</div>
			
		</article>
            <footer><center> Site academico.<br>
                </center>
                    </footer>
            </section>
	   </body>
	


	</html>