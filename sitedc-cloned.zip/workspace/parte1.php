	<!Doctype HTML>
		<html>
		<head>
			<title> DC COMICS </title>
				<meta charset="UTF-8">
				
				<link rel = "stylesheet" type = "text/css" href="csmarvel.css">
				
	   </head>
		<body id="corpo1">
        <section id="layout">
				<header>
					<img class="img1" src="dc_comics_logo_2.png" alt="Imagem">					
                    <h1 class="titulo"> DC COMICS <a href="login.php"> <img src="seu-cadastro.png" id="imgcadastro" alt="Ver seu cadastro"></a> </h1>
					
				</header>
	  <!--Menu-->
		
				<?php include"menu.php"?>

			
		
		     <a href="parte2.php"><img class="next" src="next.png" alt="Botão-próxima-página" ></a>
             <a href="index.php"> <img class="previous" src="previous.png" alt="Botão-anterior-página" ></a>

             <article id="texto"></br>
            </br>
            
            <a id="Introducao">
                </br></br>
            <p><img class="img2" src="batman1.jpg" alt="batman-na-escuridao" >
            <h3> <center>Batman</center></h3> </a>
               
        
            <div style="text-align:justify">
            <div style="text-align:justify">
            <p>A identidade secreta de Batman é Bruce Wayne, um bilionário americano, playboy, magnata de negócios, filantropo e dono da corporação Wayne Enterprises. Depois de testemunhar o assassinato dos seus pais enquanto criança, Wayne jurou vingança contra os criminosos, um juramento moderado por um sentido de justiça. Wayne treina-se então a si próprio, tanto física como intelectualmente, e cria uma persona inspirada no morcego para combater o crime: Batman.[2] Batman opera na cidade fictícia de Gotham City, e é ajudado por outros personagens incluindo o seu mordomo Alfred Pennyworth, o comissário da policia Jim Gordon, e outros aliados vigilantes como Robin. Ao contrário da maior parte dos super-heróis, Batman não tem superpoderes; faz uso do seu intelecto de gênio, da sua perícia em artes marciais, da sua destreza física, das habilidades de detective, da ciência e da tecnologia, da sua riqueza, da sua provocação ao medo e intimidação, e uma vontade indomável na sua guerra contínua contra o crime. Uma grande variedade de vilões compõem a galeria de inimigos do Batman, incluindo seu arqui-inimigo Joker.</p>
            </div>
			
		</article>
            <footer><center> Site academico.</br>
               </center>
                    </footer>
            </section>
	   </body>
	


	</html>