	<!Doctype HTML>
		<html>
		<head>
			<title> DC COMICS </title>
				<meta charset="UTF-8">
				
				<link rel = "stylesheet" type = "text/css" href="csmarvel.css">
	   </head>
		<body id="corpo1">
        <section id="layout">
				<header>
					<img class="img1" src="dc_comics_logo_2.png" alt="Imagem">					
                    <h1 class="titulo"> DC COMICS <a href="login.php"> <img src="seu-cadastro.png" id="imgcadastro" alt="Ver seu cadastro"></a> </h1>
					
				</header>
	  <!--Menu-->
		
				<?php include"menu.php"?>
		
		     <a href="parte13.php"><img class="next" src="next.png" alt="Botão-próxima-página" ></a>
                   <a href="parte11.php"> <img class="previous" src="previous.png" alt="Botão-anterior-página" ></a>
             <article id="texto"></br>
            </br>
            
            <a id="Introducao">
                </br></br><p><center>
           <img class="img2" src="sociedade1.jpg" alt="Sociedade da Justiça" >
            <h3> <center>Mais Personagens</center></h3> </a>
               
        
            <div style="text-align:justify">
<p>  A Sociedade da Justiça da América (do inglês Justice Society of America) é um grupo de heróis pertencente à editora estadunidense DC Comics, e foi o primeiro grupo de super-heróis a aparecer historicamente nas Histórias em Quadrinhos. Criada pelo editor Sheldon Mayer e escritor Gardner Fox, a SJA, como também é conhecida, teve sua primeira aparição em All-Star Comics #3 (1940), em plena Era de Ouro dos quadrinhos. O grupo incluía as versões originais de Sr. Destino (Dr. Fate), o Lanterna Verde original (Green Lantern), Joel Ciclone (Flash), o Homem-Hora (Hourman), o Sandman, o Gavião Negro (Hawkman), Átomo (Atom), e Espectro (Spectre).</p>
              
            </br></br></br>

                
<h3><center>Novos Titãs</center></h3>
<p> Os Novos Titãs são uma equipe de jovens heróis da editora americana DC Comics. Começaram com o nome de Turma Titã, na Era de Prata dos quadrinhos, mais precisamente em 1964. Com o passar dos tempos, a equipe mudou de membros e também de nomes, já foi conhecida no Brasil como Turma Titã , Os Novos Titãs, e somente Titãs. O título no Brasil foi publicado pela editora Panini Comics, de 2004 a 2010.
</p>
         
                
</div>
			
		</article>
            <footer><center> Site academico.</br>
                </center>
                    </footer>
            </section>
	   </body>
	


	</html>