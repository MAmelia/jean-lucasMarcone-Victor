	<!Doctype HTML>
		<html>
		<head>
			<title> DC COMICS </title>
				<meta charset="UTF-8">
				
				<link rel = "stylesheet" type = "text/css" href="csmarvel.css">
				
	   </head>
		<body id="corpo1">
        <section id="layout">
				<header>
					<img class="img1" src="dc_comics_logo_2.png" alt="Imagem">					
                    <h1 class="titulo"> DC COMICS <a href="login.php"> <img src="seu-cadastro.png" id="imgcadastro" alt="Ver seu cadastro"></a> </h1>
					
				</header>
	  <!--Menu-->
		<?php include"menu.php"?>
			
		
		     <a href="parte11.php"><img class="next" src="next.png" alt="Botão-próxima-página" ></a> 
                   <a href="parte9.php"> <img class="previous" src="previous.png" alt="Botão-anterior-página" ></a>
             <article id="texto"></br>
            </br>
            
            <a id="Introducao">
                </br>   
            <p><img class="img2" src="novos52.jpg" alt="Novos 52" >
            <h3> <center>Novos 52</center></h3> </a>
               
        
            <div style="text-align:justify">
<p>O número 52 tem sido usado exaustivamente pela DC Comics nos últimos anos, culminando nos Novos 52, nome dado ao conjunto de revistas lançado após o relançamento de todos os títulos de super-heróis da editora em 2011. Muitos têm se perguntado desde então o que o número 52 tem de tão especial pra ser escolhido pela editora para nomear toda uma nova linha de quadrinhos. Mesmo com o reboot, o Universo DC continua possuindo 52 Terras, portanto o nome Os Novos 52 faz referência às revistas que cobrem todo o Universo DC. Além disso, como já dito, o ano possui 52 semanas. Lançar 52 revistas por mês, sabendo que as revistas nos EUA são lançadas semanalmente (toda quarta-feira), seria como ter um ano de histórias todo mês. Em dezembro de 2005, a DC Comics lançou a mega-saga Crise Infinita, escrita por Geoff Johns, em comemoração aos 20 anos de Crise nas Infinitas Terras, história responsável pelo reboot anterior dos super-heróis da editora. A última edição de Crise Infinita foi lançada em junho de 2006, e a partir desse mês todas as revistas mensais tiveram a cronologia de suas histórias adiantada em um ano. Durante esse “ano perdido”, os três principais personagens da DC estiveram fora de ação: Superman estava sem poderes, Batman estava dedicado a uma jornada de auto-conhecimento e a Mulher Maravilha estava buscando descobrir sua verdadeira essência. Muitas outras coisas aconteceram nesse ano, suas consequências eram sentidas nas revistas com o selo “1 ano depois”, mas esses eventos só foram revelados na maxi-série 52.</p>
                 </br></br></br>
			

                
</div>
			
		</article>
            <footer><center> Site academico.</br>
                </center>
                    </footer>
            </section>
	   </body>
	


	</html>