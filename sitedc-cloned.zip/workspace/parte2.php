	<!Doctype HTML>
		<html>
		<head>
			<title> DC COMICS </title>
				<meta charset="UTF-8">
				
				<link rel = "stylesheet" type = "text/css" href="csmarvel.css">
				
	   </head>
		<body id="corpo1">
        <section id="layout">
				<header>
					<img class="img1" src="dc_comics_logo_2.png" alt="Imagem">					
                    <h1 class="titulo"> DC COMICS <a href="login.php"> <img src="seu-cadastro.png" id="imgcadastro" alt="Ver seu cadastro"></a> </h1>
					
				</header>
	  <!--Menu-->
		
					<?php include"menu.php"?>
		
		     <a href="parte3.php"><img class="next" src="next.png" alt="Botão-próxima-página" ></a>  
            <a href="parte1.php"> <img class="previous" src="previous.png" alt="Botão-anterior-página" ></a>
             <article id="texto"></br>
            </br>
            
            <a id="Introducao">
                </br></br>
            <p><img class="img2" src="superman.jpg" alt="Super-Homem" >
            <h3> <center>Superman</center></h3> </a>
               
        
            <div style="text-align:justify">
Superman é um super-herói fictício de história em quadrinhos americanas publicado pela DC Comics, uma empresa subsidiária do grupo Time Warner. Superman, entretanto, já foi adaptado para diversos outros meios desde os anos 1930, como cinema, rádio, televisão, literatura e Video game. Superman é um super-herói criado pela dupla de autores de quadrinhos Joe Shuster e Jerry Siegel. Sua primeira aparição foi apresentada na revista Action Comics #1 em 1938, nos Estados Unidos. O personagem nasceu no fictício planeta Krypton e foi chamado pelos seus pais de Kal-El (que significaria Filho das Estrelas no idioma kryptoniano). Foi mandado à Terra por seu pai, Jor-El, um cientista, momentos antes do planeta explodir. O foguete aterrissou na Terra na cidade de Smallville, onde o jovem Kal-El foi descoberto pelo casal de fazendeiros Jonathan e Martha Kent. Conforme foi crescendo, ele descobriu que tinha habilidades diferentes dos humanos. Quando não está com o tradicional uniforme azul e vermelho, ele vive como Clark Kent, repórter profissional no Planeta Diário.

Clark trabalha como repórter/jornalista no Planeta Diário com Lois Lane e com Jimmy Olsen. É um dos mais importantes personagens da cultura pop ocidental, sendo o primeiro herói dos quadrinhos a ter uma revista intitulada com seu nome: Superman #1, publicada no verão de 1939. Além disso, Superman foi licenciado e adaptado para diversas mídias, desde rádio até televisão e cinema..</p>
                 </br></br></br>
			
         

</div>
			
		</article>
            <footer><center> Site academico.</br>
                </center>
                    </footer>
            </section>
	   </body>
	


	</html>