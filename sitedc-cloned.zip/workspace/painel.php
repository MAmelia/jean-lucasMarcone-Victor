<!docytpe html>
<!DOCTYPE html>
<html>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" href="csmarvel.css">
</html>
<?php

$host = "localhost";
$user = "root";
$pass = "";
$banco = "cadastro";
$conexao = mysqli_connect($host, $user, $pass) or die(mysqli_error());
mysqli_select_db($conexao, $banco) or die(mysqli_error());
?>
<?php
session_start();
if(!isset($_SESSION["email"]) || !isset($_SESSION["senha"])) {
    header("Location: login.php");
    exit;
} else{
    echo "<center><h1>Você está logado!</h1></center>";
}
?>
        <h3>O que você deseja fazer agora?</h3>
        <form method="POST" enctype="multipart/form-data" action="upload.php">
			<label for="nome">Nome:</label><input type="text" name="nome" id="nome" /><br />
			<fieldset>
				<legend>Upload de arquivos</legend>
				<label for="arquivos">Arquivo: </label>
				<input type="hidden" name="MAX_SIZE_FILE" value="100000"> <br />
				<input type="file" name="ARQUIVO" id="arquivo"> <br />
				<input type="submit" value="Enviar o arquivo">
			</fieldset>
        
        <fieldset>
            <legend>Conferir dados/Atualizar dados/Excluir conta</legend>
        <form action="escolha.php" method="POST">
            <input type="radio" name="tipoCRUD" value="R" checked/>Conferir dados<br/>
            <input type="radio" name="tipoCRUD" value="U"/>Atualizar dados<br/>
            <input type="radio" name="tipoCRUD" value="D"/>Excluir conta<br/>
            <input type="submit" name="enviar" value="START"/>
        </form>
        </fieldset>
        <center><a href="logout.php">Desconectar</a></center>
         <footer> <p>Desenvolvido por Jean</p></footer>
        </section>
        </div>
    </body>
</html>