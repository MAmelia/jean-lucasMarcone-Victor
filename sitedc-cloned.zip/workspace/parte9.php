	<!Doctype HTML>
		<html>
		<head>
			<title> DC COMICS </title>
				<meta charset="UTF-8">
				
				<link rel = "stylesheet" type = "text/css" href="csmarvel.css">
				
	   </head>
		<body id="corpo1">
        <section id="layout">
				<header>
					<img class="img1" src="dc_comics_logo_2.png" alt="Imagem">					
                    <h1 class="titulo">DC COMICS <a href="login.php"> <img src="seu-cadastro.png" id="imgcadastro" alt="Ver seu cadastro"></a> </h1>
					
				</header>
	  <!--Menu-->
		
				<?php include"menu.php"?>
			
		
		     <a href="parte10.php"><img class="next" src="next.png" alt="Botão-próxima-página" ></a> 
                   <a href="parte8.php"> <img class="previous" src="previous.png" alt="Botão-anterior-página" ></a>
             <article id="texto"></br>
            </br>
            
            <a id="Introducao">
                </br></br>
            <p><img class="img2" src="esquadrao1.jpg" alt="Homem-Aranha" >
            <h3> <center>Esquadrão Suicida</center></h3> </a>
               
        
            <div style="text-align:justify">
<p> Criminosos condenados de alta periculosidade realizam missões impossíveis, em troca de liberdade. Todos que aceitem o convite de trabalhar no Esquadrão Suicida, ou se alistaram por conta própria, sempre que forem requisitados, devem trabalhar a serviço do Governo dos EUA e da O.N.U.. Mas, lembrem-se, as missões do Esquadrão são um convite para o suicídio. Em todas missões, alguém pode morrer. Mas morrerá pelo seu país.
                <br>
                O primeiro Esquadrão Suicida teve sua primeira aventura em The Brave and the Bold #25 (1959), era o nome informal de um pelotão durante a Segunda Guerra Mundial que reunia criminosos dispostos à lutar pelo seu país e guerrearem ao lado de soldados. Fundado por Capt. Richard Rogers Flag Sr., Dr. Hugh Evans, Jess Bright e Karin Grace, em 1940.
<br>
A segunda formação primeira aventura em Legends #3 (1986). Ao contrário de seus antecessores que usavam apenas criminosos comuns em suas missões, esta outra formação reúne os supervilões da DC Comics. O segundo grupo ficou sob o comando de Amanda Waller, Rick Flag e do veterano de Segunda Guerra Mundial, General Frank Rock.<p>
                 </br></br></br>
			
</div>
			
		</article>
            <footer><center>Site academico.</br>
                </center>
                    </footer>
            </section>
	   </body>
	


	</html>