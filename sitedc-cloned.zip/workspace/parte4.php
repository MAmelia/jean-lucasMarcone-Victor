	<!Doctype HTML>
		<html>
		<head>
			<title> DC COMICS </title>
				<meta charset="UTF-8">
				
            <link rel = "stylesheet" type = "text/css" href="csmarvel.css">
	   </head>
		<body id="corpo1">
        <section id="layout">
				<header>
					<img class="img1" src="dc_comics_logo_2.png" alt="Imagem">					
                    <h1 class="titulo"> DC COMICS <a href="login.php"> <img src="seu-cadastro.png" id="imgcadastro" alt="Ver seu cadastro"></a> </h1>
					
				</header>
	  <!--Menu-->
		
					<?php include"menu.php"?>

			
		
		     <a href="parte5.php"><img class="next" src="next.png" alt="Botão-próxima-página" ></a>
                   <a href="parte3.php"> <img class="previous" src="previous.png" alt="Botão-anterior-página" ></a>
             <article id="texto"></br>
            </br>
            
            <a id="Introducao">
                </br></br>
            <p><img class="img2" src="lanterna1.jpg" alt="Hal-Jordan" >
            <h3> <center>Lanterna Verde</center></h3> </a>
               
        
            <div style="text-align:justify">
<p> Lanterna Verde é um nome compartilhado por diversos super-heróis da DC Comics. Criado por Martin Nodell e Bill Finger, o Lanterna Verde original estreou em All-American Comics nº16 (1940). Reformulado como um novo super-herói com o mesmo nome nos anos 60, o personagem original ficou conhecido por Alan Scott e por um tempo adotou a identidade de Sentinela.

O Lanterna Verde atual foi lançado nos quadrinhos da década de 60, e também é conhecido como "O Lanterna Verde da Era de Prata". A inspiração foi a série literária Lensman de E. E. Smith. A identidade do Lanterna Verde da Era de Prata, era a de , membro fundador da Liga da Justiça da América. Apesar do excelente trabalho do desenhista Gil Kane nesse período, era um personagem de super-herói relativamente genérico até que em 1970 a DC resolveu emparelhá-lo com o Arqueiro Verde (Oliver "Ollie" Queen), em uma série de quadrinhos absolutamente inovadora e de cunho social. Essa época ajudou a consolidar o novo Lanterna Verde como um herói popular, apesar das séries subseqüentes abordarem temas mais cósmicos..</p>
                 </br></br></br>
			
         
               
			
		</article>
            <footer><center> Site academico.</br>
              </center>
                    </footer>
            </section>
	   </body>
	


	</html>