	<!Doctype HTML>
		<html>
		<head>
			<title> DC COMICS </title>
				<meta charset="UTF-8">
				
				<link rel = "stylesheet" type = "text/css" href="csmarvel.css">
	   </head>
		<body id="corpo1">
        <section id="layout">
				<header>
					<img class="img1" src="dc_comics_logo_2.png" alt="Imagem">					
                    <h1 class="titulo"> DC COMICS <a href="login.php"> <img src="seu-cadastro.png" id="imgcadastro" alt="Ver seu cadastro"></a> </h1>
					
				</header>
	  <!--Menu-->
		
				<?php include"menu.php"?>

			
		
		     <a href="parte4.php"><img class="next" src="next.png" alt="Botão-próxima-página" ></a>  
                   <a href="parte2.php"> <img class="previous" src="previous.png" alt="Botão-anterior-página" ></a>
             <article id="texto"></br>
            </br>
            
            <a id="Introducao">
                </br></br>
            <p><img class="img2" src="mulhermaravilha1.jpg" alt="Mulher-Maravilha" >
            <h3> <center>Mulher-Maravilha</center></h3> </a>
               
        
            <div style="text-align:justify">
Mulher-Maravilha  originalmente é uma super-heroína de origem grego-romana, alter ego de Diana, a princesa das Amazonas de Themyscira, também conhecida como Diana Prince no "mundo dos homens". Personagem fictícia de histórias em quadrinhos publicadas pela editora estadunidense DC Comics. Criada pelo Dr. William Moulton Marston, foi a primeira heroína da DC Comics. Sua primeira aventura foi na revista All Star Comics #8 em dezembro de 1941, nos Estados Unidos. A personagem é considerado o maior ícone pop de sexo feminino.

Princesa e Embaixadora das Amazonas da Ilha Paraíso (também conhecida como Temíscira ou Themyscira), filha da rainha das amazonas, Hipólita. Ela foi mandada ao “mundo dos homens” para propagar a paz, sendo a defensora da verdade e da vida na luta entre os homens e o firmamento, entre os mortais e os deuses. Possuindo habilidades super-humanas e seu laço da verdade, ela faz parte da Trindade da DC Comics e muitas vezes funciona como o equilíbrio entre os extremos de Superman e Batmans. Tornou-se integrante da Liga da Justiça.
</p>
                 </br></br></br>
			
         

</div>
			
		</article>
            <footer><center>Site academico.</br>
                </center>
                    </footer>
            </section>
	   </body>
	


	</html>