	<!Doctype HTML>
		<html>
		<head>
			<title> DC COMICS </title>
				<meta charset="UTF-8">
				
				<link rel="stylesheet" type="text/css" href="csmarvel.css">
				
	   </head>
		<body id="corpo1">
        <section id="layout">
				<header>
					<img class="img1" src="dc_comics_logo_2.png" alt="Imagem">					
                    <h1 class="titulo"> DC COMICS <a href="login.php"> <img src="seu-cadastro.png" id="imgcadastro" alt="Ver seu cadastro"></a> </h1>
					
				</header>
	  <!--Menu-->
		
					<?php include"menu.php"?>
			
		
		    <a href="parte1.php"> <img class="next" src="next.png" alt="Botão-próxima-página" ></a>
            <article id="texto"></br>
            <a id="Introducao"><h3><center>INTRODUÇÃO</center></h3> </a>
                <div style="text-align:justify">
                    <p>A DC Entertainment é uma editora norte-americana de histórias em quadrinhos e mídias relacionadas, sendo considerada uma das maiores companhias, ligadas a este ramo no mundo. A empresa é subsidiária da companhia Time Warner e detém a propriedade intelectual de muitos dos mais famosos personagens de quadrinhos, como Batman, Superman, Mulher-Maravilha, Lanterna Verde, Flash, Aquaman, entre outros. Por décadas a DC tem sido uma das maiores companhias de quadrinhos. Originalmente, a companhia era conhecida como National Comics e com o tempo passou a adotar a sigla "DC" que originalmente se referia a Detective Comics, uma de suas revistas mais vendidas (a qual é publicada até hoje e apresenta histórias do Batman).</p>
            
                </br>
			<img class="imgpg1" src="liga.jpg" alt="Imagem-das-animações"> 
            
        </div>
                   
            </article>
            <footer><center> Site academico.</br>
                .</center>
                    </footer>
            </section>
	   </body>
	           


	</html>