	<!Doctype HTML>
	<html>
		<head>
			<title> DC COMICS </title>
				<meta charset="UTF-8">
				
				<link rel = "stylesheet" type = "text/css" href="csmarvel.css">
				
	   </head>
		<body id="BG">
            <img src="Wonder-Woman.png" id="aranha" alt="Imagem do Homem-Aranha">
	        <section id="corpo2">
                
                <img src="DC_Logo2.png" alt="Logo Teoria da Pixar">
                <p><b>Faça parte da DC COMICS </b></p>
                <form action="autenticação.php" method="post">
                    <p>Email: <input type="text" required name="Login"/></p>
                    <p>Senha: <input type="password" required name="senha"/></p>
                    <input type="image" name="image" src="LOGIN.png" value="submit" alt="botão login" id="btncadastro">
                    <a href="cadastro.php" ><img src="cadastre.png" id="btncadastro" alt="botão cadastro"></a>
                      <a href="index.php"><center>Volte para o site</center></a>
                    <p><a href="index.php"></a></p>
                </form> 
                
                
            </section>

	   </body>
	           


	</html>