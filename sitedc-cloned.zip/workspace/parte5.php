	<!Doctype HTML>
		<html>
		<head>
			<title> DC COMICS </title>
				<meta charset="UTF-8">
				
			<link rel = "stylesheet" type = "text/css" href="csmarvel.css">
				
	   </head>
		<body id="corpo1">
        <section id="layout">
				<header>
					<img class="img1" src="dc_comics_logo_2.png" alt="Imagem">					
                    <h1 class="titulo"> DC COMICS <a href="login.php"> <img src="seu-cadastro.png" id="imgcadastro" alt="Ver seu cadastro"></a> </h1>
					
				</header>
	  <!--Menu-->
		
				<?php include"menu.php"?>

			
		
		     <a href="parte6.php"><img class="next" src="next.png" alt="Botão-próxima-página" ></a>  
                   <a href="parte4.php"> <img class="previous" src="previous.png" alt="Botão-anterior-página" ></a>
             <article id="texto"></br>
            </br>
            
            <a id="Introducao">
                </br></br>
            <p><img class="img2" src="flash.jpg" alt="Flash" >
            <h3> <center>Flash</center></h3> </a>
               
        
            <div style="text-align:justify">
Flash é um nome compartilhado por diversos super-heróis da DC Comics. Criado pelo escritor Gardner Fox e pelo artista Harry Lampert, o Flash original estreou em Flash Comics #1 (1940).

Uma vez apelidado velocista escarlate, o Flash possui "super-velocidade", consegue mover-se a uma velocidade sobre-humana ou seja incluia a habilidade de correr e mover-se extremamente rápido, usar reflexos sobre-humanos e violar certas Leis da física, podendo até mesmo ultrapassar a velocidade da luz. Até então, quatro diferentes personagens, cada qual de algum modo ganhou o poder da super-velocidade, assumiram a identidade de Flash: Jay Garrick (1940-1956), Barry Allen (1956-1986), Wally West (1986-2006, 2007-) Bart Allen (2006-2007), Barry Allen (2014-2015).

A segunda versão do Flash é geralmente considerada o primeiro herói da Era de Prata dos Quadrinhos e o super-herói permaneceu um dos mais populares desde então. Cada versão do Flash foi um membro chave ou da Sociedade da Justiça da América ou da Liga da Justiça, principais grupos da DC.

Uma versão Barry Allen, com características de Wally West foi vista em um seriado de tv, estrelado por John Wesley Shipp. Uma versão Wally West foi utilizada na série animada Liga da Justiça..</p>
</br></br></br></br></br></br>
			<p>
         
       
</div>
			
		</article>
            <footer><center> Site academico.</br>
                </center>
                    </footer>
            </section>
	   </body>
	


	</html>