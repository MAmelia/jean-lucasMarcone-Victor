	<!Doctype HTML>
		<html>
		<head>
			<title> DC COMICS </title>
				<meta charset="UTF-8">
				
				<link rel = "stylesheet" type = "text/css" href="csmarvel.css">
				
	   </head>
		<body id="corpo1">
        <section id="layout">
				<header>
					<img class="img1" src="dc_comics_logo_2.png" alt="Imagem">					
                    <h1 class="titulo"> DC COMICS <a href="login.php"> <img src="seu-cadastro.png" id="imgcadastro" alt="Ver seu cadastro"></a> </h1>
					
				</header>
	  <!--Menu-->
		
			<?php include"menu.php"?>
		
		     <a href="parte9.php"><img class="next" src="next.png" alt="Botão-próxima-página" ></a> 
                   <a href="parte7.php"> <img class="previous" src="previous.png" alt="Botão-anterior-página" ></a>
             <article id="texto"></br>
            </br>
            
            <a id="Introducao">
                </br></br>
            <p><img class="img2" src="liga.jpg" alt="Liga da Justiça" >
            <h3> <center>Liga da Justiça</center></h3> </a>
               
        
            <div style="text-align:justify">
<p>A Liga da Justiça, também conhecida como Liga da Justiça da América  é uma fictícia equipe de super-heróis publicadas pela editora americana DC Comics.

A equipe é um conjunto de super-heróis, geralmente formado por sete personagens, também conhecidos como os "Sete Magníficos". A escalação do time tem sofrido alterações ao longo dos anos, entre seus membros, destacam-se: Superman, Batman, Aquaman, Mulher Maravilha, Lanterna Verde, Flash, Caçador de Marte e Ciborgue.

Há alguns anos, a Warner Bros. criou uma versão em desenho animado do grupo, Liga da Justiça e Liga da Justiça Sem Limites. Foi muito bem recebido pela crítica e por muitos dos fãs, não só da equipe, mas também leitores de outras editoras. 
    <br>
 Liga surgiu como uma versão da Terra-1 da Sociedade da Justiça (Terra-2), primeiro grupo de super-heróis nas histórias em quadrinhos, que estreou em All Star Comics #3 (1941). Em 1956, com as primeiras aparições do Barry Allen, a nova versão do Flash foi amplamente considerada o por iniciar a chamada Era de Prata dos quadrinhos, durante o qual muitas personagens da editora sofreram um reformulação. Com isso, personagens da Era de Ouro dos quadrinhos passaram a ser conhecido por habitarem a Terra-2, enquanto os da nova era habitavam a Terra-1, sendo resultado de Terras paralelas. Com os super-heróis perderam popularidade com o final da 2ª Guerra Mundial, os títulos foram sendo substituídos por temas mais atraentes aos leitores, como western e romances. Foi só nos anos 60 que a DC resgatou a ideia de uma superequipe e criou a Liga.</p>
                 </br></br>
			
         
                
</div>
			
		</article>
            <footer><center> Site academico.</br>
              </center>
                    </footer>
            </section>
	   </body>
	


	</html>