
<ul id="menu">
				                  <li> <a href="index.php">INTRODUÇÃO</a> </li>
				    <li> <a href="parte1.php">Batman</a> </li>
				    <li> <a href="parte2.php">Superman</a> </li>
				    <li> <a href="parte3.php">Mulher-Maravilha</a></li>
				    <li> <a href="parte4.php">Lanterna Verde</a> </li>
				    <li> <a href="parte5.php">Flash</a> </li>
				    <li> <a href="parte6.php">Aquaman</a> </li>
				    <li> <a href="parte7.php">Cyborg</a> </li>
				    <li> <a href="parte8.php">Liga da Justiça</a> </li>
				    <li> <a href="parte9.php"> Esquadrão Suicida </a></li>
                    <li> <a href="parte10.php">Novos 52</a> </li>
                    <li> <a href="parte11.php">Rebirth</a> </li>
                    <li> <a href="parte12.php">Mais Personagens</a>
                    <li> <a href="parte13.php">Séries DC</a> </li>
                    <li> <a href="parte14.php">Filmes</a> </li>
                   
				</ul>
 