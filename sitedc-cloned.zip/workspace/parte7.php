	<!Doctype HTML>
		<html>
		<head>
			<title> DC COMICS </title>
				<meta charset="UTF-8">
				
				<link rel = "stylesheet" type = "text/css" href="csmarvel.css">
	   </head>
		<body id="corpo1">
        <section id="layout">
				<header>
					<img class="img1" src="dc_comics_logo_2.png" alt="Imagem">					
                    <h1 class="titulo">DC COMICS <a href="login.php"> <img src="seu-cadastro.png" id="imgcadastro" alt="Ver seu cadastro"></a> </h1>
					
				</header>
	  <!--Menu-->
		
            
            <?php include"menu.php"?>

			
		
		     <a href="parte8.php"><img class="next" src="next.png" alt="Botão-próxima-página" ></a>
                   <a href="parte6.php"> <img class="previous" src="previous.png" alt="Botão-anterior-página" ></a>
             <article id="texto"></br>
            </br>
            
            <a id="Introducao">
                </br></br>
            <p><img class="img2" src="cyborg.png" alt="Cyborg" >
            <h3> <center>Cyborg</center></h3> </a>
               
        
            <div style="text-align:justify">
<p> Filho único dos cientistas Silas e Elionore Stone, Victor Stone cresceu cercado pela ciência, sendo induzido a seguir a carreira dos pais, pois eles descobriram que Vic possuía um Q.I. de 170. Entretanto o garoto não teve uma infância normal, justamente por seus pais se dedicarem totalmente à ciência. Quando jovem, Vic começou a se relacionar com o encrenqueiro Ron Evers, metendo-se em problemas diversas vezes. Mas Vic continuou amigo de Ron, pois se sentia muito só e sem a atenção de seus pais.

Por insistência de Elionore, Silas permitiu que Victor frequentasse uma escola pública. Assim, o garoto fez muitos amigos e começou a desenvolver seu potencial atlético. Neste tempo, Vic conheceu sua primeira namorada, Marcy Reynolds. Victor treinava arduamente na esperança de se ingressar nos Jogos Olímpicos. Seu pai se irritou, pois seus planos para Victor eram outros. Queria que seu filho fosse um cientista, o que acarretou num relacionamento conturbado entre os dois. Um dia, Vic decidiu visitar seus pais nos Laboratórios S.T.A.R (ou STAR Labs.) Silas e Elionore trabalhavam em dois projetos: Estudo e observação de outras dimensões e desenvolvimento de peças cibernéticas para serem usadas em soldados deficientes. Ao observar outra dimensão, Silas permitiu acidentalmente que uma criatura surgisse de uma barreira interdimensional. A entidade matou Elionore e deixou Victor gravemente ferido.

Desesperado com a situação, Silas não queria que seu filho tivesse o mesmo destino da mãe. Decidiu reconstituir o corpo dele com os protótipos em estudo. Utilizou aço reforçado, polímeros especiais e plástico. Vic sobreviveu e Cyborg nasceu. Irritado com seu pai e com sua situação atual, Vic se isolou da sociedade, mudando-se para a “Cozinha do Inferno”, local onde Ravena encontrou Vic e o convidou a se juntar aos Titãs. Satisfeito por seu filho estar se relacionando com o grupo, Silas construiu a Torre Titã e a deu de presente a ele e seus amigos. Alguns meses mais tarde, Silas veio a falecer devido a um envenenamento radioativo. Neste tempo, Vic se reconciliou com o pai e permaneceu junto dele até o final.</p>
                 </br></br></br>
			
         

</div>
			
		</article>
            <footer><center> Todos os direitos reservados.</br>
                Adriano Santos - 41587634.</center>
                    </footer>
            </section>
	   </body>
	


	</html>